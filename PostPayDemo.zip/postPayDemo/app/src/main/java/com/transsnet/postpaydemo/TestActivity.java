package com.transsnet.postpaydemo;

import android.app.Activity;

/**
 * Author:  zengfeng
 * Time  :  2020/12/28 18:01
 * Des   :
 */
public class TestActivity extends Activity {
} 
