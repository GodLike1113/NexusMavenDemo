package com.transsnet.postpaydemo;

/**
 * Author:  zengfeng
 * Time  :  2020/12/28 18:11
 * Des   :
 */
public class AppInit {
    private static Class inputPwdActivityClass;

    public static void setInputPwdActivityClass(Class cls) {
        inputPwdActivityClass = cls;
    }
} 
